[issues]: https://github.com/derisamedia/luci-theme-alpha/issues
[issues-badge]: https://img.shields.io/badge/Issues-welcome-brightgreen.svg?style=flat-square
[release]: https://github.com/derisamedia/luci-theme-alpha/releases
[release-badge]: https://img.shields.io/badge/download-check_releases-blue
[group]: https://facebook.com/groups/indowrt
[group-badge]: https://img.shields.io/badge/visit_Facebook-Comunity-cyan
[discord]: https://discord.gg/gdZwmDQGUm
[discord-badge]: https://img.shields.io/badge/visit_Discord-Comunity-blue
[paypal]: https://www.paypal.com/paypalme/derisamedia
[paypal-badge]: https://img.shields.io/badge/Donate-Paypal_me-blue







<div align="center">

# luci-theme-alpha (BETA)

<img src="https://raw.githubusercontent.com/derisamedia/luci-theme-alpha/master/luasrc/brand.png">

[![issues][issues-badge]][issues]
[![release][release-badge]][release]
[![group][group-badge]][group]
[![discord][discord-badge]][discord]
[![paypal][paypal-badge]][paypal]


Luci theme for Official Openwrt and Alpha OS build ,based on bootstrap and material luCi theme refferences,
<summary>Preview Screenshoot</summary>
<p>
  
![image](https://raw.githubusercontent.com/derisamedia/luci-theme-alpha/master/ss1.png)
  
![image](https://raw.githubusercontent.com/derisamedia/luci-theme-alpha/master/ss2.png)

![image](https://raw.githubusercontent.com/derisamedia/luci-theme-alpha/master/ss3.png)

![image](https://raw.githubusercontent.com/derisamedia/luci-theme-alpha/master/mobileview1.png)

![image](https://raw.githubusercontent.com/derisamedia/luci-theme-alpha/master/mobileview2.png)

![image](https://raw.githubusercontent.com/derisamedia/luci-theme-alpha/master/mobileview3.png)

</p>

# Contributors
<a href="https://github.com/derisamedia/luci-theme-alpha/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=derisamedia/luci-theme-alpha" />
</a>


### FYI

alpha os is my idea which wants to develop the OpenWrt community in Indonesia, even the world, thanks to friends who have supported this alpha-os theme, hopefully given health to all of us.


(old text) Mr. Sibondt once they said 'jalan ditempat komunitas indo', that's what moved my heart to make an innovation that I named alpha os (alpha = initial version, because it hasn't been perfect until now 😁)

donate
buy me a padang rice or coffee
https://saweria.co/derisamedia
